from django.contrib import admin
from .models import Employe,Department,Location,Asset,Assign,Category

class AssetsAdmin(admin.ModelAdmin):
    list_display = ['name','id','phone','email','gender','joined_Date','location','Department',]
    search_fields = ['name','phone','email','location','Department']
    list_filter = ['gender','location','Department']
    list_per_page = 10

admin.site.register(Employe,AssetsAdmin)    
admin.site.register(Department)
admin.site.register(Location)

class AssetAdmin(admin.ModelAdmin):
    list_display = ['category','asset_Name','bill_No','purchase_Date','location','quantity']
    search_fields = ['category','asset_Name','bill_No','purchase_Date','location','quantity']
    list_filter = ['category','asset_Name','location','purchase_Date']
    list_per_page = 10

admin.site.register(Asset,AssetAdmin)    
admin.site.register(Category)

class AssetAdmin(admin.ModelAdmin):
    list_display = ['assetname','employename','assigndate','department','location']
    search_fields = ['assetname','employename','assigndate','department','location']
    list_filter = ['assetname','employename','assigndate','department','location']
    list_per_page = 10

admin.site.register(Assign,AssetAdmin)  