from django.contrib import admin
from django.urls import path, include
from Assets import views


urlpatterns = [   
   #  login & logout urls
    path('',views.LoginPage,name='login'),
    path('logout',views.LogoutPage,name='logout'),
    path('read/logout',views.LogoutPage,name='logout'),
    path('login',views.LoginPage,name='login'),
    
   # Employe urls
    path('read', views.Read.as_view(), name="read"),
    path('employe_list', views.Read.as_view(), name="read"),
    path('update/<int:pk>/', views.Update.as_view(), name="update"),
    path('delete/<int:pk>/', views.Delete.as_view(), name="delete"),
    path('employe_form', views.Create.as_view(), name="create"),
   # Assets urls
    path('asset_list', views.AssetRead.as_view(), name="Assetread"),
    path('Assetupdate/<int:pk>/', views.AssetUpdate.as_view(), name="Assetupdate"),
    path('Assetdelete/<int:pk>/', views.AssetDelete.as_view(), name="Assetdelete"),
    path('asset_form', views.AssetCreate.as_view(), name="Assetcreate"),
   # Assign urls 
   path('assign_form', views.assign_form, name='assign_create'),
   path('assign_read', views.assign_list, name='assign_read'),
   path('assignupdate/<int:id>', views.assign_form, name='assign_update'),
   path('data_delete/<str:assign_id>', views.data_delete, name='data_delete'),

   path('users/<int:id>/edit/',views.user_edit, name='user_edit'),
   path('users/<str:users_id>/delete/',views.user_delete, name='user_delete'),
   path('user_list',views.user_list,name='user_list'),
   path('signup',views.SignupPage,name='signup'),
]

