from django.db import models
class Location(models.Model):
    location = models.CharField(max_length=25)
    def __str__(self):
        return self.location   

class Department(models.Model):
    department = models.CharField(max_length=25)
    def __str__(self):
        return self.department
   
Gender =(
    ('','Select'),
    ('Male','Male'),
    ('Female','Female'),
    ('Other','Other')
)

class Employe(models.Model):
    name = models.CharField(default=None,max_length=40)
    phone = models.CharField(default=None,max_length=10)
    email = models.EmailField(default=None,max_length=25)
    gender = models.CharField(max_length=25,choices=Gender)
    joined_Date = models.DateField(max_length=100)
    location = models.ForeignKey(Location, on_delete=models.CASCADE) 
    Department = models.ForeignKey(Department, on_delete=models.CASCADE)
    def __str__(self):
        return "%s" %(self.name) 


class Category(models.Model):
    category = models.CharField(max_length=25)
    def __str__(self):
        return self.category 

    
class Asset(models.Model):
    category = models.ForeignKey(Category,default=None, on_delete=models.CASCADE)
    asset_Name = models.CharField(max_length=100)
    bill_No = models.CharField(max_length=25)
    purchase_Date = models.DateField(max_length=100)
    location = models.ForeignKey(Location, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=0)  
    def __str__(self):
        return "%s %s" %( self.asset_Name,self.category)  
   
  
class Assign(models.Model):
    assetname = models.ForeignKey(Asset,default=None, on_delete=models.CASCADE)    
    employename = models.ForeignKey(Employe,default=None, on_delete=models.CASCADE) 
    assigndate = models.DateField(max_length=20)
    department = models.ForeignKey(Department,default=None, on_delete=models.CASCADE)
    location = models.ForeignKey(Location,default=None, on_delete=models.CASCADE)

