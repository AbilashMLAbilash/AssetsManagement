from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, HttpResponse
from django.views.decorators.cache import cache_control
from django.contrib import messages

# from django.shortcuts import render, redirect
# from django.contrib.auth import authenticate, login
# from django.contrib.auth.forms import UserCreationForm

# def admin_login(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         password = request.POST['password']
#         user = authenticate(request, username=username, password=password)
#         if user is not None and user.is_staff and user.is_superuser:
#             login(request, user)
#             return redirect('admin:index')
#         else:
#             return render(request, 'accounts/admin_login.html', {'error': 'Invalid login credentials.'})
#     else:
#         return render(request, 'accounts/admin_login.html')

# def staff_login(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         password = request.POST['password']
#         user = authenticate(request, username=username, password=password)
#         if user is not None and user.is_staff:
#             login(request, user)
#             return redirect('staff_dashboard')
#         else:
#             return render(request, 'accounts/staff_login.html', {'error': 'Invalid login credentials.'})
#     else:
#         return render(request, 'accounts/staff_login.html')

# def staff_signup(request):
#     if request.method == 'POST':
#         form = UserCreationForm(request.POST)
#         if form.is_valid():
#             user = form.save()
#             user.is_staff = True
#             user.save()
#             login(request, user)
#             return redirect('staff_dashboard')
#     else:
#         form = UserCreationForm()
#     return render(request, 'accounts/staff_signup.html', {'form': form})


# Create your views here.
@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def HomePage(request):
    return render (request,'base.html')

def LoginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return redirect('/employe_list')
        else:
            messages.error(request,"Invalid username or password..")
            return redirect('/')

    return render (request,'login.html')
    
def LogoutPage(request):
    logout(request)
    return redirect('/')   

from Assets.models import Employe
from django.views.generic import ListView,CreateView,UpdateView,DeleteView
from django.urls import reverse_lazy,reverse
from django.shortcuts import render,HttpResponseRedirect
from django.db.models import Q 
from.forms import EmployeForm 
from django.contrib.messages.views import SuccessMessageMixin
from django.contrib import messages
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin


class Create(SuccessMessageMixin,CreateView):
    model = Employe
    form_class = EmployeForm
    template_name = 'Assets/employe_form.html'
    success_url = reverse_lazy('read')
    success_message= "Employe: %(name)s Created Successfully !"

class Read(LoginRequiredMixin,ListView):
    login_url = '/login/'
    model = Employe
    queryset = Employe.objects.all()
    # function
    def get_queryset(self):
        q = self.request.GET.get('q')
        if q:
            object_list = self.model.objects.filter(
                Q(name__icontains=q) | Q(phone__icontains=q) | Q(email__icontains=q) |
                Q(gender__icontains=q) | Q(joined_Date__icontains=q) 
            )
        else:
            object_list = self.model.objects.all()    
        return object_list 

class Update(SuccessMessageMixin,UpdateView):
    model = Employe
    form_class = EmployeForm
    template_name = 'Assets/employe_form.html'
    success_url = reverse_lazy('read')
    success_message= "Employe: %(name)s Updated Successfully !"

class Delete(DeleteView):
    model = Employe
    def get_success_url(self):
        messages.success(self.request,"Employe Deleted Successfully !")
        return reverse("read")
        
#-------------------------------------------------------------------------------------------------

from Assets.models import Asset
from.forms import AssetForm

class AssetCreate(SuccessMessageMixin,CreateView):
    model = Asset
    form_class = AssetForm
    template_name = 'Assets/asset_form.html'
    success_url = reverse_lazy('Assetread')
    success_message= "Asset %(asset_Name)s Added Successfully"

class AssetRead(ListView):
    model = Asset
    queryset = Asset.objects.all()
    # function
    def get_queryset(self):
        q = self.request.GET.get('q')
        if q:
            object_list = self.model.objects.filter(
                Q(asset_Name__icontains=q) | Q(bill_No__icontains=q) | Q(purchase_Date__icontains=q) |
                Q(quantity__icontains=q)
            )
        else:
            object_list = self.model.objects.all()    
        return object_list 

class AssetUpdate(SuccessMessageMixin,UpdateView):
    model = Asset
    form_class = AssetForm
    template_name = 'Assets/asset_form.html'
    success_url = reverse_lazy('Assetread')
    success_message= "Asset %(asset_Name)s Updated Successfully"

class AssetDelete(DeleteView):
    model = Asset
    def get_success_url(self):
        messages.success(self.request,"Asset Deleted Successfully !")
        return reverse("Assetread")   

#---------------------------------------------------------------------------------------------------

from django.shortcuts import render, redirect
from .models import Assign 
from.forms import AssignForm 

# R
def assign_list(request):
    context = {'assign_list':Assign.objects.all()}
    return render(request, "Assets/assign_list.html", context)

# C/U
def assign_form(request, id = None):
    if request.method == "POST":
        if id == None:
            form = AssignForm(request.POST)
        else:
            assign = Assign.objects.get(pk = id)
            form = AssignForm(request.POST, instance = assign)
        if form.is_valid():
            form.save()
        return redirect('/assign_read')
    else:
        if id == None:
            form = AssignForm()
        else:
            assign = Assign.objects.get(pk = id)
            form = AssignForm(instance = assign)
        return render(request, "Assets/assign_form.html",{'form':form})            
# D

def data_delete(request, assign_id):
    assign = Assign.objects.get(id = assign_id)
    assign.delete()
    return HttpResponseRedirect('/assign_read')     
      

# --------------------------------- xxxx -------------------------------------------------------------
# views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages

@login_required
def user_list(request):
    users = User.objects.all()
    context = {'users': users}
    return render(request, 'user_list.html', context)

@login_required
def user_edit(request, id=None):
    users = get_object_or_404(User, pk=id)

    if request.method == 'POST':
        # Process form data to update the user object
        users.username = request.POST['username']
        users.email = request.POST['email']
        users.save()
        messages.success(request, f"{users.username} has been updated successfully.")
        return redirect('user_list')

    context = {'users': users}
    return render(request, 'user_edit.html', context)

@login_required
def user_delete(request, users_id):
    users = User.objects.get(id=users_id)

    if request.method == 'POST':
        # Delete the user object
        users.delete()
        messages.success(request, f"{users.username} has been deleted successfully.")
        return redirect('user_list')

    context = {'users': users}
    return render(request, 'user_delete.html', context)

def SignupPage(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')

        if pass1!=pass2:
            return HttpResponse("Your password and confrom password are not Same!!")
        else:

            my_user=User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect('login')
        
    return render (request,'signup.html') 