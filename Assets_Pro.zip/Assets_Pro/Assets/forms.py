from django import forms
from .models import Employe 

class EmployeForm(forms.ModelForm):
    class Meta:
        model = Employe
        fields = ('name','phone','email','gender','joined_Date','location','Department')
        labels = {
            'name':'Name',
            'email':'Email',
        }
        # placeholdser
        widgets = {
            'name': forms.TextInput(attrs={'placeholder':'Employe name'}),
            'phone': forms.TextInput(attrs={'placeholder':'Phone number'}),
            'email': forms.TextInput(attrs={'placeholder':'Email Address'}), 
            'joined_Date':forms.DateInput(
                attrs={
                    'style':'font-size: 13px; cursor: pointer',
                    'type':'date',
                    'onkeydown': 'return false',
                    'min':'2000-01-01',
                    'max':'2025-12-31',
                }
            ),
            'gender': forms.Select(
                attrs={
                    'class':'form-control'
                }
            ),
            'location': forms.Select(
                attrs={
                    'class':'form-control'
                }
            ),
            'Department': forms.Select(
                attrs={
                    'class':'form-control'
                }
            )
        }

    def __init__(self, *args, **kwargs):
        super(EmployeForm,self).__init__(*args, **kwargs)
        self.fields['gender'].choices = [("","----Select----"),] + list(self.fields['gender'].choices)[1:]
        self.fields['location'].empty_label = "----Select----"  
        self.fields['Department'].empty_label = "----Select----"
        self.fields['email'].required = True

from django import forms
from .models import Asset

class AssetForm(forms.ModelForm):
    class Meta:
        model = Asset
        fields = ('category','asset_Name','bill_No','purchase_Date','location','quantity') 
        labels = {
        
        }
        # placeholdser
        widgets = {
            'asset_Name': forms.TextInput(attrs={'placeholder':'Enter Asset Name'}),
        
            'bill_No': forms.TextInput(attrs={'placeholder':'Enter Bill No'}),
            'purchase_Date':forms.DateInput(
                attrs={
                    'style':'font-size: 13px; cursor: pointer',
                    'type':'date',
                    'onkeydown': 'return false',
                    'min':'2000-01-01',
                    'max':'2025-12-31',
                }
            ),
            'location': forms.Select(
                attrs={
                    'class':'form-control'
                }
            ),
            'category': forms.Select(
                attrs={
                    'class':'form-control'
                }
            )
        }

    def __init__(self, *args, **kwargs):
        super(AssetForm,self).__init__(*args, **kwargs)
        self.fields['category'].empty_label = "----Select----"  
        self.fields['location'].empty_label = "----Select----" 


from django import forms
from .models import Assign

class AssignForm(forms.ModelForm):
    class Meta:
        model = Assign

        fields = ( 'assetname','employename','assigndate','department','location')
        labels = {
            'assetname':'Asset Name',
            'employename':'Employe Name',
            'assigndate':'Assign Date',
        }
        # placeholdser
        widgets = {
           
            'assigndate':forms.DateInput(
                attrs={
                    'style':'font-size: 13px; cursor: pointer',
                    'type':'date',
                    'onkeydown': 'return false',
                    'min':'2000-01-01',
                    'max':'2025-12-31',
                }
            ),
            'department': forms.Select(
                attrs={
                    'class':'form-control'
                }
            ),
            'location': forms.Select(
                attrs={
                    'class':'form-control'
                }
            ),
            'assetname': forms.Select(
                attrs={
                    'class':'form-control'
                }
            ),
            'employename': forms.Select(
                attrs={
                    'class':'form-control'
                }
            )
        }

    def __init__(self, *args, **kwargs):
        super(AssignForm,self).__init__(*args, **kwargs) 
        self.fields['department'].empty_label = "----Select----"
        self.fields['location'].empty_label = "----Select----"
        self.fields['assetname'].empty_label = "----Select----"
        self.fields['employename'].empty_label = "----Select----"
    
            